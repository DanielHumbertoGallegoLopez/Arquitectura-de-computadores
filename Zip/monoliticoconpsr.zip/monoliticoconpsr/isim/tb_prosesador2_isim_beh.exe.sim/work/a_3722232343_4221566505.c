/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/Kimtaro/Desktop/monoliticoconpsr/Unidad_de_control.vhd";



static void work_a_3722232343_4221566505_p_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned char t8;
    unsigned int t9;
    int t11;
    char *t12;
    int t14;
    char *t15;
    int t17;
    char *t18;
    int t20;
    char *t21;
    int t23;
    char *t24;
    int t26;
    char *t27;
    int t29;
    char *t30;
    int t32;
    char *t33;
    int t35;
    char *t36;
    int t38;
    char *t39;
    int t41;
    char *t42;
    int t44;
    char *t45;
    int t47;
    char *t48;
    int t50;
    char *t51;
    int t53;
    char *t54;
    int t56;
    char *t57;
    int t59;
    char *t60;
    int t62;
    char *t63;
    int t65;
    char *t66;
    int t68;
    char *t69;
    int t71;
    char *t72;
    int t74;
    char *t75;
    int t77;
    char *t78;
    char *t80;
    char *t81;
    char *t82;
    char *t83;
    char *t84;

LAB0:    xsi_set_current_line(19, ng0);
    t1 = (t0 + 4756);
    t3 = (t0 + 2912);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 6U);
    xsi_driver_first_trans_fast_port(t3);
    xsi_set_current_line(20, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 4762);
    t8 = 1;
    if (2U == 2U)
        goto LAB5;

LAB6:    t8 = 0;

LAB7:    if (t8 != 0)
        goto LAB2;

LAB4:    xsi_set_current_line(107, ng0);
    t1 = (t0 + 5046);
    t3 = (t0 + 2912);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 6U);
    xsi_driver_first_trans_fast_port(t3);

LAB3:    t1 = (t0 + 2832);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(21, ng0);
    t6 = (t0 + 1192U);
    t7 = *((char **)t6);
    t6 = (t0 + 4764);
    t11 = xsi_mem_cmp(t6, t7, 6U);
    if (t11 == 1)
        goto LAB12;

LAB36:    t12 = (t0 + 4770);
    t14 = xsi_mem_cmp(t12, t7, 6U);
    if (t14 == 1)
        goto LAB13;

LAB37:    t15 = (t0 + 4776);
    t17 = xsi_mem_cmp(t15, t7, 6U);
    if (t17 == 1)
        goto LAB14;

LAB38:    t18 = (t0 + 4782);
    t20 = xsi_mem_cmp(t18, t7, 6U);
    if (t20 == 1)
        goto LAB15;

LAB39:    t21 = (t0 + 4788);
    t23 = xsi_mem_cmp(t21, t7, 6U);
    if (t23 == 1)
        goto LAB16;

LAB40:    t24 = (t0 + 4794);
    t26 = xsi_mem_cmp(t24, t7, 6U);
    if (t26 == 1)
        goto LAB17;

LAB41:    t27 = (t0 + 4800);
    t29 = xsi_mem_cmp(t27, t7, 6U);
    if (t29 == 1)
        goto LAB18;

LAB42:    t30 = (t0 + 4806);
    t32 = xsi_mem_cmp(t30, t7, 6U);
    if (t32 == 1)
        goto LAB19;

LAB43:    t33 = (t0 + 4812);
    t35 = xsi_mem_cmp(t33, t7, 6U);
    if (t35 == 1)
        goto LAB20;

LAB44:    t36 = (t0 + 4818);
    t38 = xsi_mem_cmp(t36, t7, 6U);
    if (t38 == 1)
        goto LAB21;

LAB45:    t39 = (t0 + 4824);
    t41 = xsi_mem_cmp(t39, t7, 6U);
    if (t41 == 1)
        goto LAB22;

LAB46:    t42 = (t0 + 4830);
    t44 = xsi_mem_cmp(t42, t7, 6U);
    if (t44 == 1)
        goto LAB23;

LAB47:    t45 = (t0 + 4836);
    t47 = xsi_mem_cmp(t45, t7, 6U);
    if (t47 == 1)
        goto LAB24;

LAB48:    t48 = (t0 + 4842);
    t50 = xsi_mem_cmp(t48, t7, 6U);
    if (t50 == 1)
        goto LAB25;

LAB49:    t51 = (t0 + 4848);
    t53 = xsi_mem_cmp(t51, t7, 6U);
    if (t53 == 1)
        goto LAB26;

LAB50:    t54 = (t0 + 4854);
    t56 = xsi_mem_cmp(t54, t7, 6U);
    if (t56 == 1)
        goto LAB27;

LAB51:    t57 = (t0 + 4860);
    t59 = xsi_mem_cmp(t57, t7, 6U);
    if (t59 == 1)
        goto LAB28;

LAB52:    t60 = (t0 + 4866);
    t62 = xsi_mem_cmp(t60, t7, 6U);
    if (t62 == 1)
        goto LAB29;

LAB53:    t63 = (t0 + 4872);
    t65 = xsi_mem_cmp(t63, t7, 6U);
    if (t65 == 1)
        goto LAB30;

LAB54:    t66 = (t0 + 4878);
    t68 = xsi_mem_cmp(t66, t7, 6U);
    if (t68 == 1)
        goto LAB31;

LAB55:    t69 = (t0 + 4884);
    t71 = xsi_mem_cmp(t69, t7, 6U);
    if (t71 == 1)
        goto LAB32;

LAB56:    t72 = (t0 + 4890);
    t74 = xsi_mem_cmp(t72, t7, 6U);
    if (t74 == 1)
        goto LAB33;

LAB57:    t75 = (t0 + 4896);
    t77 = xsi_mem_cmp(t75, t7, 6U);
    if (t77 == 1)
        goto LAB34;

LAB58:
LAB35:    xsi_set_current_line(104, ng0);
    t1 = (t0 + 5040);
    t3 = (t0 + 2912);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 6U);
    xsi_driver_first_trans_fast_port(t3);

LAB11:    goto LAB3;

LAB5:    t9 = 0;

LAB8:    if (t9 < 2U)
        goto LAB9;
    else
        goto LAB7;

LAB9:    t4 = (t2 + t9);
    t5 = (t1 + t9);
    if (*((unsigned char *)t4) != *((unsigned char *)t5))
        goto LAB6;

LAB10:    t9 = (t9 + 1);
    goto LAB8;

LAB12:    xsi_set_current_line(24, ng0);
    t78 = (t0 + 4902);
    t80 = (t0 + 2912);
    t81 = (t80 + 56U);
    t82 = *((char **)t81);
    t83 = (t82 + 56U);
    t84 = *((char **)t83);
    memcpy(t84, t78, 6U);
    xsi_driver_first_trans_fast_port(t80);
    goto LAB11;

LAB13:    xsi_set_current_line(27, ng0);
    t1 = (t0 + 4908);
    t3 = (t0 + 2912);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 6U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB11;

LAB14:    xsi_set_current_line(30, ng0);
    t1 = (t0 + 4914);
    t3 = (t0 + 2912);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 6U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB11;

LAB15:    xsi_set_current_line(33, ng0);
    t1 = (t0 + 4920);
    t3 = (t0 + 2912);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 6U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB11;

LAB16:    xsi_set_current_line(36, ng0);
    t1 = (t0 + 4926);
    t3 = (t0 + 2912);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 6U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB11;

LAB17:    xsi_set_current_line(39, ng0);
    t1 = (t0 + 4932);
    t3 = (t0 + 2912);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 6U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB11;

LAB18:    xsi_set_current_line(42, ng0);
    t1 = (t0 + 4938);
    t3 = (t0 + 2912);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 6U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB11;

LAB19:    xsi_set_current_line(45, ng0);
    t1 = (t0 + 4944);
    t3 = (t0 + 2912);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 6U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB11;

LAB20:    xsi_set_current_line(49, ng0);
    t1 = (t0 + 4950);
    t3 = (t0 + 2912);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 6U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB11;

LAB21:    xsi_set_current_line(53, ng0);
    t1 = (t0 + 4956);
    t3 = (t0 + 2912);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 6U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB11;

LAB22:    xsi_set_current_line(57, ng0);
    t1 = (t0 + 4962);
    t3 = (t0 + 2912);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 6U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB11;

LAB23:    xsi_set_current_line(61, ng0);
    t1 = (t0 + 4968);
    t3 = (t0 + 2912);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 6U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB11;

LAB24:    xsi_set_current_line(65, ng0);
    t1 = (t0 + 4974);
    t3 = (t0 + 2912);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 6U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB11;

LAB25:    xsi_set_current_line(69, ng0);
    t1 = (t0 + 4980);
    t3 = (t0 + 2912);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 6U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB11;

LAB26:    xsi_set_current_line(73, ng0);
    t1 = (t0 + 4986);
    t3 = (t0 + 2912);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 6U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB11;

LAB27:    xsi_set_current_line(77, ng0);
    t1 = (t0 + 4992);
    t3 = (t0 + 2912);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 6U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB11;

LAB28:    xsi_set_current_line(81, ng0);
    t1 = (t0 + 4998);
    t3 = (t0 + 2912);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 6U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB11;

LAB29:    xsi_set_current_line(85, ng0);
    t1 = (t0 + 5004);
    t3 = (t0 + 2912);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 6U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB11;

LAB30:    xsi_set_current_line(89, ng0);
    t1 = (t0 + 5010);
    t3 = (t0 + 2912);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 6U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB11;

LAB31:    xsi_set_current_line(91, ng0);
    t1 = (t0 + 5016);
    t3 = (t0 + 2912);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 6U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB11;

LAB32:    xsi_set_current_line(94, ng0);
    t1 = (t0 + 5022);
    t3 = (t0 + 2912);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 6U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB11;

LAB33:    xsi_set_current_line(98, ng0);
    t1 = (t0 + 5028);
    t3 = (t0 + 2912);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 6U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB11;

LAB34:    xsi_set_current_line(101, ng0);
    t1 = (t0 + 5034);
    t3 = (t0 + 2912);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 6U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB11;

LAB59:;
}


extern void work_a_3722232343_4221566505_init()
{
	static char *pe[] = {(void *)work_a_3722232343_4221566505_p_0};
	xsi_register_didat("work_a_3722232343_4221566505", "isim/tb_prosesador2_isim_beh.exe.sim/work/a_3722232343_4221566505.didat");
	xsi_register_executes(pe);
}
